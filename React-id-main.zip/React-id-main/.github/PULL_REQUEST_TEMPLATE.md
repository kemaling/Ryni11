<!--

Thank you for the PR! Contributors like you keep React awesome!

Please see the Contribution Guide for guidelines:

https://github.com/reactjs/react.dev/blob/main/CONTRIBUTING.md

If your PR references an existing issue, please add the issue number below

-->

Closes <!-- mention the issue that you're trying to close with this PR -->

## Description

Translate the <!-- mention the page title that you're translating --> page.
Page URL: <!-- mention the URL to the page that you're translating -->
