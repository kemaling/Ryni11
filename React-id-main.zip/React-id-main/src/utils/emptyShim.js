/*
 * Copyright (c) Facebook, Inc. and its affiliates.
 */

// We use this file to shim out dependencies that we don't need.
// See next.config.js.
